<!--
<div id="layoutAuthentication_footer">
             <footer class="py-4 bg-light mt-auto">
                 <div class="container-fluid px-4">
                     <div class="d-flex align-items-center justify-content-between small">
                         <div class="text-muted" style="color:black;"></div>
                         <div>
                             <a href="about-us-page.php" target="_blank">Copyright &copy; <script>document.write(new Date().getFullYear())</script> <?php echo $author; ?> •</a>
 
                         </div>
                     </div>
                 </div>
             </footer>
         </div>
-->