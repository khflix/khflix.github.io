<?php
$website_version="v1.4";
$author="TR Coder";
$email="tarunraghav202@gmail.com";
$contact_form="https://form.jotform.com/222351082093448";

$website_title="XStreamPlayer Pro Admin Panel";
$logo="./admin/Images/IMG_20220212_121740.JPG";
$YoutubeChannelID="UCMMS04AArq9iMUnXFsT8ybA";
$description="XStreamPlayer Pro Admin Panel | Created by TR Coder";  
$keywords="https://telegram.me/trcoderofficial";
?>