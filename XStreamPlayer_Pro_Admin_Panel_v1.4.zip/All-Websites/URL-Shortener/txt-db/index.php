<?php
	
	// this file to hide txt files from users.
	die("Access not allowed!"); // you can replace this line to: header("location: ../index.php"); will be redirect user to index page!

?>