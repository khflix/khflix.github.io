<script language="javascript">
document.location="./admin/about-us-page.php";
</script>