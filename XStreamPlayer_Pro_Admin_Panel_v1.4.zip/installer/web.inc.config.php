<?php
$website_version="web_version";
$author="your_name";
$email="your_email";
$contact_form="cont_form";

$title="web_title";
$logo="img_logo";
$YoutubeChannelID="yt_channel_id";
$description="full_description";  
$keywords="some_keywords";
?>