<?php include '../includes/config-web-info.php'; ?>
  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core Menu</div>
                            <a class="nav-link" href="./dashboard.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            
<a class="nav-link" href="add-video.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-plus"></i></div>
                                Add Video
                            </a>

<a class="nav-link" href="./video-list.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Video List
                            </a>

                            <a class="nav-link" href="manage-users.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                                Manage Users
                            </a>

<a class="nav-link" href="./manage-settings.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-solid fa-cog"></i></div>
                                Manage Settings
                            </a>
<!--
<a class="nav-link" href="Adminer/adminer-4.8.1.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-solid fa-database"></i></div>
                                Manage Database
                            </a>
                            
                 <a class="nav-link" href="../tiny-file-manager/">

                                <div class="sb-nav-link-icon"><i class="fas fa-folder-open"></i></div>
                                Tiny File Manager
                            </a>
-->

 <a class="nav-link" href="bwdates-report-ds.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-calendar"></i></div>
                                B/w Dates Report
                            </a>

<a class="nav-link" href="../index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-solid fa-external-link-alt"></i></div>
                                Open Website
                            </a>

<a class="nav-link" href="../index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-lock"></i></div>
                                Change Password
                            </a>

                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Signout
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>